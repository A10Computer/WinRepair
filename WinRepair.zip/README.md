# 🛠️ Windows Repair Tools

## 🧩 Features

### 🛡️ System Repair

* &#x20;SFC System File Check (`sfc /scannow`)
* &#x20;SFC Verification Only
* &#x20;DISM CheckHealth (quick system image check)
* &#x20;DISM ScanHealth (deep analysis)
* &#x20;DISM RestoreHealth (system repair)
* &#x20;Component Store Cleanup
* &#x20;Deep Cleanup with ResetBase option

\---

### 🌐 Network Tools

* &#x20;ARP Cache Reset
* &#x20;DNS Flush
* &#x20;Windows Firewall Reset
* &#x20;Winsock \& TCP/IP Reset
* &#x20;IP Renew (Release / Renew)

\---

### 🧹 Cleanup Tools

* &#x20;Disk Cleanup (cleanmgr)
* &#x20;Outlook Cache Cleanup
* &#x20;Microsoft Teams Cache Cleanup

\---

### 🧰 Windows Administration

* &#x20;Device Manager
* &#x20;Registry Editor
* &#x20;Services Manager
* &#x20;System Configuration (msconfig)
* &#x20;Windows Update Settings

\---

### 🚀 Advanced Tools

* &#x20;CHKDSK Disk Check
* &#x20;Windows Update Repair (reset services + components)

\---

## ⚙️ Requirements

* &#x20;PowerShell 5.1 or higher
* &#x20;Administrator privileges (required for most functions)

## 

## **WinRepair.exe - Free to use at your own risk!**

