# 🛠 Windows Repair Tool

![Platform](https://img.shields.io/badge/platform-Windows%2010%20%7C%2011-blue)
![Language](https://img.shields.io/badge/language-DE%20%7C%20EN-green)
![License](https://img.shields.io/badge/license-Freeware-lightgrey)

Kostenloses, portables Reparatur- und Wartungstool für Windows 10 und 11 – keine Installation nötig.

## Funktionen

- **Systemreparatur:** SFC-Scan, DISM (CheckHealth / ScanHealth / RestoreHealth / Cleanup), CHKDSK mit Laufwerksauswahl
- **Netzwerk:** ARP-/DNS-Reset, Firewall-Reset, TCP/IP-Stack-Reset, Netzwerkadapter neu starten, IP erneuern
- **Bereinigung:** Datenträgerbereinigung, Outlook-/Teams-/Browser-Cache, Temp-Ordner, Prefetch
- **Windows-Tools:** Geräte-Manager, Registry-Editor, Dienste, Systemkonfiguration, Datenträgerverwaltung, Aktivierungsstatus
- **Windows Update:** Update-Einstellungen öffnen, Update-Dienste zurücksetzen
- Zweisprachige Oberfläche (Deutsch/Englisch) mit automatischer Erkennung und manuellem Umschalter
- Admin-Rechte nur bei Bedarf – kein erzwungener UAC-Prompt beim Start
- Sicherheitsabfragen vor allen kritischen bzw. spürbaren Aktionen
- Aktions-Log unter `C:\Temp\WindowsRepairTool.log`
- Läuft als eigenständige `.exe`, keine Installation erforderlich

## Voraussetzungen

- Windows 10 oder Windows 11
- Für einige Funktionen: Administratorrechte (werden im Tool bei Bedarf per Klick angefragt)

## Nutzung

1. `WindowsRepairTool.exe` herunterladen und starten
2. Hinweis- und Haftungsausschluss-Dialog bestätigen
3. Gewünschte Funktion per Klick ausführen

## Haftungsausschluss

Die Nutzung dieses Tools erfolgt auf eigene Verantwortung. Einige Funktionen greifen tief in das System ein (z. B. Registry, Datenträgerprüfung, Update-Zurücksetzung) und können bei falscher Anwendung zu Datenverlust oder Systemproblemen führen.

Es wird **keinerlei Gewähr oder Haftung** für Schäden jeglicher Art übernommen, die durch die Nutzung dieses Tools entstehen. Die Nutzung ist kostenlos und erfolgt „wie besehen" (as-is), ohne jegliche Garantie.

## Autor

© 2026 Bjoern Scherf – Alpha10Computer
