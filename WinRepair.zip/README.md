# 🛠 Alpha10 Windows Repair Tool

![Platform](https://img.shields.io/badge/platform-Windows%2010%20%7C%2011-blue)
![Version](https://img.shields.io/badge/version-3.3.0-informational)
![Language](https://img.shields.io/badge/language-DE%20%7C%20EN-green)
![License](https://img.shields.io/badge/license-Freeware-lightgrey)

Reparieren, prüfen, Privatsphäre schützen – kostenlos und portabel für Windows 10 und 11, ohne Installation.

## Funktionen

- **Neu: Windows Privacy** – Telemetrie, Werbung und Datenweitergabe einzeln abschalten, jede Funktion mit eigenem Code. Bereits Geschütztes wird erkannt; jede Änderung wird gesichert und lässt sich exakt rückgängig machen.
- **Systemanalyse** – Schnell, Standard oder Gründlich: Autostart, Treiber, Datenträger, Bluescreens, Hitze, Secure Boot, Browser-Kaperung u. v. m., mit Bericht.
- **Reparaturen per Klick** – SFC, DISM, CHKDSK, Windows Update, Netzwerk, Drucker, Suche, Store-Apps, Audio, WMI.
- **Bereinigung** – Datenträger, Outlook-, Teams- und Browser-Cache.
- **Fehlercode-Erklärer** – Windows-Fehlernummern in verständlichen Worten.
- **Sicher** – Adminrechte nur bei Bedarf, Rückfrage vor spürbaren Eingriffen; Defender, SmartScreen und Windows Update bleiben unangetastet.

## Nutzung

1. `Alpha10-WinRepair.exe` im .zip Ordner herunterladen, entpacken und starten
2. Hinweis bestätigen
3. Funktion per Klick ausführen

Voraussetzung: Windows 10 oder 11. Protokoll: `C:\Temp\WindowsRepairTool.log`

## Haftungsausschluss

Nutzung auf eigene Verantwortung, ohne Gewähr („wie besehen“). Einige Funktionen greifen tief ins System ein; für Schäden wird keine Haftung übernommen.

## Autor

© 2026 Bjoern Scherf – Alpha10Computer
